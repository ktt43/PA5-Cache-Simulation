#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

//Extract Tag and SetIndex
long int extractTag(long int binary,int blockbit,int indexbit){
	long int tag=(binary>>blockbit)>>indexbit;
	return tag;
}
long int extractSet(long int binary, int blockbit,long int mask){
	long int set = (binary>>blockbit)&mask;
	return set;
}
//Find power
int pow2(int number){
	int pow=0;
	int x=1;
	for(;x<number;pow++){
		x=2*x;
	}
return pow;
}
//Create Struct for cache block, tag,index
struct cacheLine{
        int valid;
        long int originalAddress;
        long int tag;
        long int setIndex;
//	int age;
};
//NONPREFETCH READ
void read(struct cacheLine**c,char RW,long int original,long int tag,long int setIndex,int numCacheLine,int *memRead,int *cacheMiss,int *cacheHit,int *memWrite){
	int i=0,x=0;
	int memRe=*memRead;
	int miss=*cacheMiss;
	int hit=*cacheHit;
	int memWr=*memWrite;
	
	for(;i<numCacheLine;i++){
		if(c[setIndex][i].valid!=1){	//If Miss/Invalid
			if(RW=='R'){
				memRe++;
				miss++;
			}else{
				miss++;
				memRe++;
				memWr++;
			}
			*memWrite=memWr;
			*memRead=memRe;
			*cacheMiss=miss;			
			c[setIndex][i].valid=1;
			c[setIndex][i].originalAddress=original;
			c[setIndex][i].tag=tag;
			c[setIndex][i].setIndex=setIndex;
			return;	
		}else{
			if(c[setIndex][i].tag==tag){		//Line is Valid
				hit++;
				if(RW=='W'){
					memWr++;			
				}
				*cacheHit=hit;
				*memWrite=memWr;	

//LRU Currently not working
			/*	if(repPol==2){
					int temp;
					int tempval=c[setIndex][i].valid;
					long int tempadd=c[setIndex][i].originalAddress;
					long int temptag=c[setIndex][i].tag;
					long int tempset=c[setIndex][i].setIndex;
					for(temp=i;temp<numCacheLine;temp++){
						c[setIndex][temp]=c[setIndex][temp+1];
						if(temp==(numCacheLine-1)){
							c[setIndex][temp].valid=tempval;
							c[setIndex][temp].originalAddress=tempadd;
							c[setIndex][temp].tag=temptag;	
							c[setIndex][temp].setIndex=tempset;
						}
					}
				}
*/
				return;
//ELSE IF WHEN THE BLOCK IS VALID BUT TAG NOT MATCHED
			} else if(i==(numCacheLine-1)){ 
				for(;x<numCacheLine;x++){
					if(x==(numCacheLine-1)){
						c[setIndex][x].valid=1;
						c[setIndex][x].originalAddress=original;
						c[setIndex][x].tag=tag;
						c[setIndex][x].setIndex=setIndex;
					}else{
						c[setIndex][x]=c[setIndex][x+1];
					}
				}	
				miss++;
				memRe++;
					if(RW=='W'){
						memWr++;
					}
				*memWrite=memWr;
				*cacheMiss=miss;
				*memRead=memRe;
				return;
			}			
		}	
	}
}	

//LOAD A+BLOCKSIZE, SAME STRUCTURE AS THE OTHER READS WITHOUT WRITING BACK TO MEMORY
void readAblock(struct cacheLine**c, long int newAddress,int numCacheLine,int *memRead,int blockbit,int setindexbit,long int mask){
	int i=0,x=0;
	int memRe=*memRead;
	long int newTag=extractTag(newAddress,blockbit,setindexbit);
	long int newsetIndex=extractSet(newAddress,blockbit,mask);
	for(i=0;i<numCacheLine;i++){
		if(c[newsetIndex][i].valid!=1){
			memRe++;
			*memRead=memRe;
		c[newsetIndex][i].valid=1;
		c[newsetIndex][i].originalAddress=newAddress;
		c[newsetIndex][i].tag=newTag;
		c[newsetIndex][i].setIndex=newsetIndex;
		return;
		}else{
			if(c[newsetIndex][i].tag==newTag){
				return;
			} else if(i==(numCacheLine-1)){
				for(x=0;x<numCacheLine;x++){
					if(x==(numCacheLine-1)){
						c[newsetIndex][x].valid=1;
						c[newsetIndex][x].originalAddress=newAddress;
						c[newsetIndex][x].tag=newTag;
						c[newsetIndex][x].setIndex=newsetIndex;
					} else{
						c[newsetIndex][x]=c[newsetIndex][x+1];
					}
				}
			memRe++;
			*memRead=memRe;
			return;
			}
		}
	}
}


//READ FOR PREFETCH, SAME STRUCTURE AS OTHER READS BUT WITH LOADING A+BLOCKSIZE WHEN CACHE MISS
void readp(struct cacheLine**c,char RW, long int original,long int tag,long int setIndex,int blockSize,int numCacheLine,int *memRead,int*cacheMiss, int *cacheHit, int*memWrite,int blockBit,int setIndexBit,long int mask){
	int i=0;
	int x=0;
	int memRe=*memRead;
	int miss=*cacheMiss;
	int hit=*cacheHit;
	int memWr=*memWrite;
	long int AwithblockSize;
	
	for(i=0;i<numCacheLine;i++){
		if(c[setIndex][i].valid!=1){
			if(RW=='R'){
				memRe++;
				miss++;
			}else{
				miss++;
				memRe++;
				memWr++;
			}	
		*memWrite=memWr;
		*memRead=memRe;
		*cacheMiss=miss;
		c[setIndex][i].valid=1;
		c[setIndex][i].originalAddress=original;
		c[setIndex][i].tag=tag;
		c[setIndex][i].setIndex=setIndex;
	//READ A+Blocksize
		AwithblockSize=original+blockSize;
		readAblock(c,AwithblockSize,numCacheLine,&memRe,blockBit,setIndexBit,mask);
		*memRead=memRe;
		return;	
		}else{
			if(c[setIndex][i].tag==tag){
				hit++;
				if(RW=='W'){
					memWr++;
				}
				*cacheHit=hit;
				*memWrite=memWr;
				return;
			}else if(i==(numCacheLine-1)){
				for(x=0;x<numCacheLine;x++){
					if(x==(numCacheLine-1)){
						c[setIndex][x].valid=1;
						c[setIndex][x].originalAddress=original;
						c[setIndex][x].tag=tag;
						c[setIndex][x].setIndex=setIndex;	
					}else{
						c[setIndex][x]=c[setIndex][x+1];
					}
				}
				miss++;
				memRe++;
				if(RW=='W'){
					memWr++;
				}
				*memWrite=memWr;
				*cacheMiss=miss;
				*memRead=memRe;
				AwithblockSize=original+blockSize;
				readAblock(c,AwithblockSize,numCacheLine,&memRe,blockBit,setIndexBit,mask);
				*memRead=memRe;
				return;
			}
		}
	}
}
//RESET THE STRUCT CACHE
void resetCache(struct cacheLine**c ,int row,int col){
	int i;
	int x;
	for(i=0;i<row;i++){
		for(x=0;x<col;x++){
			c[i][x].valid=0;
			c[i][x].originalAddress=0;
			c[i][x].tag=0;
			c[i][x].setIndex=0;
		}
	}

}
int main(int argc,char**argv){
	//Read arguments
	int cacheSize=atoi(argv[1]);
	int blockSize=atoi(argv[4]);
	int n;
//	int repPol;
	char RW;
	long int binary;	
	int numSet;
	int blockBit;
	int setIndexBit;	
	int hits=0,misses=0,reads=0,writes=0;
	//associativity: 1->direct, 2->fully associative cache, 3->n-way associative 
	//Cache Size = #Sets * #Cache Line * Block Size
	//cacheSize  = numSet 	    n        blockSize
	if(strcmp(argv[2],"direct")==0){
		numSet=cacheSize/blockSize;
		n=1;
	}else if(strcmp(argv[2],"assoc")==0){
		numSet=1;
		n=cacheSize/numSet/blockSize;
	}else{
	//READ FROM A CHAR TYPE--> CONVERTED
		n=argv[2][6]-'0';
		numSet=cacheSize/blockSize/n;	
	}
/*
	//repPol: 1->FIFO, 2->LRU
	if(strcmp(argv[3],"fifo")==0){
		repPol=1;
	}else{
		repPol=2;
	}
*/
	//Offset and Index bit
	blockBit=pow2(blockSize);
	setIndexBit=pow2((cacheSize/blockSize)/n);

	FILE *file= fopen(argv[5],"r");
	long int pc;
	long int TagHex;
	long int SetHex;
	long int mask;
	//Create 2d Array Struct Type
	struct cacheLine**cache=(struct cacheLine**)malloc(numSet*sizeof(struct cacheLine*));
        int r=0;
	//Create Columns/#of in each Set
        for(;r<numSet;r++){
        	cache[r]=(struct cacheLine*)malloc(n*sizeof(struct cacheLine));
        }

	//SET VALIDITY TO BE INITIALLY 0
	r=0;int i=0;
        for(;r<numSet;r++){
		for(;i<n;i++){
		cache[r][i].valid=0;
		}
	}
	//CREATE MASK TO GET THE SET INDEX ADDRESS
	mask=((1<<setIndexBit)-1);

	//NO PREFETCH
	while(fscanf(file,"%lx: %c 0x%lx",&pc,&RW,&binary)==3){
		TagHex=extractTag(binary,blockBit,setIndexBit);
		SetHex=extractSet(binary,blockBit,mask);
		read(cache,RW,binary,TagHex,SetHex,n,&reads,&misses,&hits,&writes);
	}
	printf("no-prefetch\nCache hits: %d\nCache misses: %d\nMemory reads: %d\nMemory writes: %d\n",hits,misses,reads,writes);
	hits=0,misses=0,reads=0,writes=0; 

	//WITH PREFETCH
	rewind(file);
	//RESET CACHE
	resetCache(cache,numSet,n);
	hits=0;misses=0;reads=0;writes=0;
	
	while(fscanf(file,"%lx: %c 0x%lx",&pc,&RW,&binary)==3){	
		TagHex=extractTag(binary,blockBit,setIndexBit);
		SetHex=extractSet(binary,blockBit,mask);
		readp(cache,RW,binary,TagHex,SetHex,blockSize,n,&reads,&misses,&hits,&writes,blockBit,setIndexBit,mask);
		}

	printf("with-prefetch\nCache hits: %d\nCache misses: %d\nMemory reads: %d\nMemory writes: %d\n",hits,misses,reads,writes);

	fclose(file);
	free(cache);
return 0;
}
